from fastapi import FastAPI


subapi = FastAPI(openapi_prefix="/member")